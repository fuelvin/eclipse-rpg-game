# RPGGame

Complete pixel RPG with tilemap generator, battling system, and level system by Elvin. Created with Java using the Eclipse IDE.

Created Dec. 2017 - Jun. 2018

Added to Github on May 2021


INSTRUCTIONS

Arrow keys or WASD to move.

Z to select option during a battle.

Z to go to next dialogue.

Z or Space to attack during the attack portion.
