package Game;

public interface ClickListener {
	
	public void onClick();
}
